3 files:
1. revisions-Zhang-Chonglin
2. HW1-Zhang-Chonglin.pdf
3. HW1-Zhang-Chonglin.ipynb


revisions-Zhang-Chonglin: For question 9, there are 4 pictures for significant changing
For question 10, there are 3 pictures for significant changing 
Full versions picture: last two cells are showing full versions of problem 9 and problem 10

For HW1-Zhang-Chonglin.ipynb: 
1. For question 9, I change goalp and dfs function. GOAL = 70
    Using the question 9 goalp function to find the match goal. 
    For question 9 of dfs function, using node_list.sort(key=lambda x: x.h) in dfs while loop.

2. For question 10, I change goalp and dfs function. GOAL = 60
    Using the question 10 goalp function to find the match goal.
    For question 10 of dfs function, using node_list.sort(key=lambda x: x.cost + x.h) in dfs while loop.